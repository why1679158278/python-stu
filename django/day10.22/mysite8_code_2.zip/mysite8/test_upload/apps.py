from django.apps import AppConfig


class TestUploadConfig(AppConfig):
    name = 'test_upload'
