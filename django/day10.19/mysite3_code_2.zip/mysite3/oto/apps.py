from django.apps import AppConfig


class OtoConfig(AppConfig):
    name = 'oto'
