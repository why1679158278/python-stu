from django.apps import AppConfig


class OtmConfig(AppConfig):
    name = 'otm'
