from django.contrib import admin
from .models import Book
# Register your models here.

# 1. 模型管理器类
class BookManager(admin.ModelAdmin):
    list_display = ['id','title','pub','price','market_price']
    list_display_links = ['id','title']
    list_filter = ['pub']
    search_fields = ['title','pub']
    list_editable=['market_price']

# 2. 注册并绑定
admin.site.register(Book,BookManager)