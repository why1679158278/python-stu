from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from .models import Book


# Create your views here.
def all_book(request):
    books = Book.objects.all()
    return render(request,
                  'bookstore/all_book.html',
                  locals())


def update_book(request, bid):
    # 0 根据编号获取数据
    try:
        book = Book.objects.get(id=bid)
    except Exception as e:
        return HttpResponse('bid is error')
    # 1 GET请求,拿页面 (页面中有数据)
    if request.method == 'GET':
        return render(request,
                      'bookstore/update_book.html', locals())

    elif request.method == 'POST':
        # 2 POST请求,提交数据
        m_price = request.POST['market_price']
        book.market_price = m_price
        book.save()
        # 重定向到图书列表
        return HttpResponseRedirect('/bookstore/all_book')


def delete_book(request):
    bid = request.GET.get('bid')
    try:
        book = Book.objects.get(id=bid)
        book.delete()
    except Exception as e:
        print('bid is error')
        return HttpResponse('删除失败')
    # 重定向到图书列表
    return HttpResponseRedirect('/bookstore/all_book')
