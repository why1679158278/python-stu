from django.apps import AppConfig


class MtmConfig(AppConfig):
    name = 'mtm'
