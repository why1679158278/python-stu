from django.db import models


# Create your models here.
class Book(models.Model):
    title = models.CharField("书名", max_length=20)
    # 000.00
    price = models.DecimalField("单价", max_digits=5,
                                decimal_places=2)
    # 新增属性要有默认值
    pub = models.CharField('出版社', max_length=50, default='')
    market_price = models.DecimalField("零售价", max_digits=5,
                                       decimal_places=2, default=0.0)

    # 重写
    def __str__(self):
        return '%s_%s_%s_%s' % (self.title,
                                self.pub,
                                self.price,
                                self.market_price)
    class Meta:
        db_table = 'book'
        verbose_name = '图书'
        verbose_name_plural = '图书'


class Author(models.Model):
    name = models.CharField("姓名", null=False,max_length=20)
    age = models.IntegerField("年龄", default=1)
    email = models.EmailField("邮箱", null=True)



    class Meta:
        db_table = 'author'
