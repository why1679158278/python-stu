from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render

html = '''
<form method='post' action="/test_get_post?a=100&b=200">
    姓名:<input type="text" name="username">
    <input type='submit' value='登录'>
</form>
'''


def test_get_post(request):
    if request.method == 'GET':
        print(request.GET)
        # print(request.GET['a'])
        # print(request.GET['b'])
        # 推荐的获取方式
        print(request.GET.get('b', 0))
        # 获取列表
        print(request.GET.getlist('a'))
        return HttpResponse(html)
    elif request.method == 'POST':
        a = request.GET.get('a')
        b = request.GET.get('b')
        username = request.POST['username']
        return HttpResponse('北京欢迎您:%s,%s,%s' % (username, a, b))


def test_html(request):
    # 方式 1
    # # 1 加载模板
    # t = loader.get_template('test_html.html')
    # # 2 将字典数据传递给模板,返回html字符串
    # dict1 = {}
    # dict1['name'] = 'tarena'
    # html = t.render(dict1)
    # # 3 将html字符串作为HttpResponse的参数
    # return HttpResponse(html)

    # 方式 2
    dict1 = {}
    dict1['name'] = '马志国'
    dict1['age'] = 30
    dict1['hobby'] = ['吃饭', '睡觉', '上课']
    dict1['scores'] = {'语文': 80, '数学': 100, '英语': 99}
    return render(request, 'test_html.html', dict1)
