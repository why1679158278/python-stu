from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render

html = '''
<form method='post' action="/test_get_post?a=100&b=200">
    姓名:<input type="text" name="username">
    <input type='submit' value='登录'>
</form>
'''


def test_get_post(request):
    if request.method == 'GET':
        print(request.GET)
        # print(request.GET['a'])
        # print(request.GET['b'])
        # 推荐的获取方式
        print(request.GET.get('b', 0))
        # 获取列表
        print(request.GET.getlist('a'))
        return HttpResponse(html)
    elif request.method == 'POST':
        a = request.GET.get('a')
        b = request.GET.get('b')
        username = request.POST['username']
        return HttpResponse('北京欢迎您:%s,%s,%s' % (username, a, b))


class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show(self):
        info = '姓名:%s,年龄%s' % (self.name, self.age)
        return info


def Hello():
    return "hello,world"


def test_html(request):
    # 方式 1
    # # 1 加载模板
    # t = loader.get_template('test_html.html')
    # # 2 将字典数据传递给模板,返回html字符串
    # dict1 = {}
    # dict1['name'] = 'tarena'
    # html = t.render(dict1)
    # # 3 将html字符串作为HttpResponse的参数
    # return HttpResponse(html)

    # # 方式 2
    # dict1 = {}
    # dict1['name'] = '马志国'
    # dict1['age'] = 30
    # dict1['hobby'] = ['吃饭', '睡觉', '上课']
    # dict1['scores'] = {'语文': 80, '数学': 100, '英语': 99}
    # dict1['p1'] = Person('tarena', 18)
    # dict1['func1'] = Hello
    #
    # return render(request, 'test_html.html', dict1)

    # 方式 3
    name = '马志国'
    age = 16
    hobby = ['吃饭', '睡觉', '上课']
    scores = {'语文': 80, '数学': 100, '英语': 99}
    p1 = Person('tarena', 18)
    func1 = Hello
    script = '<script>alert(110)</script>'

    f4 = ['赵四', '刘能', '小沈阳', '宋小宝']

    return render(request, 'test_html.html', locals())


def mycal(request):
    if request.method == 'GET':
        # 返回页面
        return render(request, 'mycal.html')
    elif request.method == 'POST':
        # 根据提交参数,返回计算结果
        pass
