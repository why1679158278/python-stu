from django.http import HttpResponse

html = '''
<form method='post' action="/test_get_post">
    姓名:<input type="text" name="username">
    <input type='submit' value='登录'>
</form>
'''


def test_get_post(request):
    if request.method == 'GET':
        return HttpResponse(html)
    elif request.method == 'POST':
        username = request.POST['username']
        return HttpResponse('北京欢迎您:%s' % username)
