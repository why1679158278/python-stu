from django.http import HttpResponse
from django.shortcuts import render
from django.urls import reverse


def default_view(request):
    return render(request, 'base.html')


def news_view(request):
    return render(request, 'news.html')


def sport_view(request):
    # url反向解析,根据名字->url
    print(reverse('sp_url'))
    return render(request, 'sport.html')


def pagen_view(request, n):
    return HttpResponse('this is page %s' % n)


def test_static(request):
    return render(request,'test_static.html')