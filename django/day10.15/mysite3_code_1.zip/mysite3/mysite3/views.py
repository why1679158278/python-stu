from django.shortcuts import render


def default_view(request):
    return render(request, 'base.html')


def news_view(request):
    return render(request, 'news.html')


def sport_view(request):
    return render(request, 'sport.html')
