from django.utils.deprecation import MiddlewareMixin


class MyMiddleware(MiddlewareMixin):
    def process_request(self, request):
        print("中间件方法 process_request 被调用")

    def process_view(self, request, callback, callback_args, callback_kwargs):
        print("中间件方法 process_view 被调用")

    def process_response(self, request, response):
        print("中间件方法 process_response 被调用")
        return response

class MyMiddleware2(MiddlewareMixin):
    def process_request(self, request):
        print("中间件方法 process_request2 被调用")

    def process_view(self, request, callback, callback_args, callback_kwargs):
        print("中间件方法 process_view2 被调用")

    def process_response(self, request, response):
        print("中间件方法 process_response2 被调用")
        return response
