import time

from django.http import HttpResponse
from django.views.decorators.cache import cache_page


# @cache_page(600)
def test_cache(request):
    t1 = time.time()
    # time.sleep(3)
    print('--test_cache view in--')
    result = 't1 is %s' % t1
    return HttpResponse(result)


def test_mw(request):
    print('--middle view in--')
    return HttpResponse('test mw!')
