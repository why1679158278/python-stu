from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin


class MyMiddleware(MiddlewareMixin):
    def process_request(self, request):
        print("中间件方法 process_request 被调用")

    def process_view(self, request, callback, callback_args, callback_kwargs):
        print("中间件方法 process_view 被调用")

    def process_response(self, request, response):
        print("中间件方法 process_response 被调用")
        return response


class MyMiddleware2(MiddlewareMixin):
    def process_request(self, request):
        print("中间件方法 process_request2 被调用")

    def process_view(self, request, callback, callback_args, callback_kwargs):
        print("中间件方法 process_view2 被调用")

    def process_response(self, request, response):
        print("中间件方法 process_response2 被调用")
        return response


import re


class MyMW(MiddlewareMixin):
    # 字典: 键是IP地址,值是访问次数
    visit_times = {}

    # 进url之前
    def process_request(self, request):
        # 1.获取客户端IP地址
        cip = request.META['REMOTE_ADDR']
        # 2.只对以/test开头的url做限制
        if not re.match(r'^/test', request.path_info):
            return
        # 3.获取次数
        times = self.visit_times.get(cip, 0)
        if times >= 5:
            return HttpResponse('No Way!')
        # 4. 存储访问次数
        self.visit_times[cip] = times + 1
        # 5. 打印次数
        print('%s visit we %s times' % (cip, self.visit_times[cip]))
