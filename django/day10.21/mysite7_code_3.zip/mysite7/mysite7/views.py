import time

from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.cache import cache_page


# @cache_page(600)
def test_cache(request):
    t1 = time.time()
    # time.sleep(3)
    print('--test_cache view in--')
    result = 't1 is %s' % t1
    return HttpResponse(result)


def test_mw(request):
    print('--middle view in--')
    return HttpResponse('test mw!')


def test_csrf(request):
    if request.method == 'GET':
        return render(request, 'test_csrf.html')
    elif request.method == 'POST':
        username = request.POST['username']
        result = 'username is %s' % username
        return HttpResponse(result)


def test_page(request):
    # 1.要分页显示的数据
    list1 = ['a', 'b', 'c', 'd', 'e']
    # 2.创建分页对象
    paginator = Paginator(list1, 2)
    # 3.获取页码
    cur_page = request.GET.get('page', 1)
    # 4.获取page对象
    page = paginator.page(cur_page)
    # 5.返回
    return render(request, 'test_page.html', locals())


import csv


def test_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="mybook.csv"'
    all_book = [
        {'id': 1, 'title': 'python'},
        {'id': 2, 'title': 'c++'},
        {'id': 3, 'title': 'Java'},
    ]
    writer = csv.writer(response)
    writer.writerow(['编号', '书名'])
    for b in all_book:
        writer.writerow([b['id'], b['title']])

    return response
