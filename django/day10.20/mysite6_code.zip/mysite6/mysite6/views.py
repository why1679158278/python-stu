from django.http import HttpResponse


def set_cookies(request):
    # 在响应中,由服务器设置cookies
    # 实际项目中的uname的值可能从登录请求中过来,
    # 先验证,验证后保存到cookies中.
    resp = HttpResponse('设置cookies成功!')
    resp.set_cookie('uname', 'tedu', 600)
    return resp


def get_cookies(request):
    uname = request.COOKIES.get('uname', '未命名')
    result = 'uname is %s' % uname
    return HttpResponse(result)


def del_cookies(request):
    resp = HttpResponse('删除cookies!')
    resp.delete_cookie('uname')
    return resp


def set_session(request):
    request.session['uname'] = 'tedu'
    return HttpResponse('set session is OK!')


def get_session(request):
    uname = request.session.get('uname', '未命名')
    result = 'uname is %s' % uname
    return HttpResponse(result)


def del_session(request):
    del request.session['uname']
    return HttpResponse('del session is OK!')
