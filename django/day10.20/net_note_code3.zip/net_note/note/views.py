from django.http import HttpResponseRedirect
from django.shortcuts import render


# Create your views here.
# 登录认证的装饰器
def login_check(fn):
    def wrap(request,*args,**kwargs):
        if 'uname' not in request.session or 'uid' not in request.session:
            c_uname = request.COOKIES.get('uname')
            c_uid = request.COOKIES.get('uid')
            if not c_uname or not c_uid:
                return HttpResponseRedirect('/user/login')
            else:
                # 回写session
                request.session['uname'] = c_uname
                request.session['uid'] = c_uid
        return fn(request,*args,**kwargs)
    return wrap

@login_check
def add_view(request):
    if request.method == 'GET':
        return render(request,'note/add_note.html')
    elif request.method == 'POST':
        pass

