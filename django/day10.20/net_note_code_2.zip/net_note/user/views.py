from django.http import HttpResponse
from django.shortcuts import render

from .models import User

import hashlib


# Create your views here.

def reg_view(request):
    if request.method == 'GET':
        return render(request, 'user/register.html')
    elif request.method == 'POST':
        username = request.POST.get('username')
        password_1 = request.POST.get('password_1')
        password_2 = request.POST.get('password_2')
        # 1.为空检查
        if not username or not password_1:
            return HttpResponse('用户名和密码不允许为空')
        # 2 两次密码要一致
        if password_1 != password_2:
            return HttpResponse('两次密码不一致!')
        # 3 用户名是否已被占用
        old_user = User.objects.filter(username=username)
        if old_user:
            return HttpResponse('用户名已占用!')
        # 4 是否会直接保存输入的 '密码' 呢?
        md5 = hashlib.md5()
        md5.update(password_1.encode())
        # 口令的Hash值
        password_h = md5.hexdigest()
        # 5 数据库中添加数据
        try:
            User.objects.create(username=username,
                                password=password_h)
        except Exception as e:
            return HttpResponse('用户名已占用!')
        return HttpResponse('用户注册成功!')


def login_view(request):
    if request.method == 'GET':
        # 检查session数据,判断以前是否登录过
        if 'uname' in request.session and 'uid' in request.session:
            return HttpResponse("您已经登录!")

        return render(request, 'user/login.html')
    elif request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 1.为空检查
        if not username or not password:
            return HttpResponse('用户名和密码不允许为空')

        # 2.获取对象
        try:
            old_user = User.objects.get(username=username)
        except Exception as e:
            print('the error is %s' % e)
            return HttpResponse('用户名或密码错误!')
        # 计算登录口令的Hash
        md5 = hashlib.md5()
        md5.update(password.encode())
        password_h = md5.hexdigest()
        if password_h != old_user.password:
            return HttpResponse('用户名或密码错误!')
        # 在session保存登录状态(信息)
        request.session['uname']=old_user.username
        request.session['uid'] = old_user.id
        return HttpResponse('登录成功!')




def logout_view(request):
    pass
