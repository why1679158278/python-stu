from django.http import HttpResponse


def news_view(request):
    return HttpResponse('<h1>您访问的是新闻页面</h1')


def sports_view(request):
    return HttpResponse('<h2>这是体育页面,湖人刚刚取得总冠军!</h2>')


def default_page(request):
    return HttpResponse('<h2>这是默认首页</h2>')


def page_1(request):
    return HttpResponse('这是第1个页面')


def page_2(request):
    return HttpResponse('这是第2个页面')


def page_num(request, num):
    return HttpResponse('这是编号为%s的页面' % (num))


def calc_view(request, num1, op, num2):
    if op not in ['add', 'sub', 'mul']:
        return HttpResponse('op is wrong~')
    res = 0
    if op == 'add':
        res = num1 + num2
    elif op == 'sub':
        res = num1 - num2
    elif op == 'mul':
        res = num1 * num2
    return HttpResponse('计算结果为%s' % res)


def birthday_view(request, y, m, d):
    # 输出url字符串
    # 在服务器的终端打印
    print(request.path_info)
    print(request.method)
    return HttpResponse('您的生日为:%s-%s-%s' % (y, m, d))
