"""
1--20乘积
"""

result = 1 

for i in range(1,21):
    result *= i 

print(result)
