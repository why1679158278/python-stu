"""
dict 客户端

* 发起请求
* 获取数据进行展示
"""

from socket import *

# 服务端地址
ADDR = ("127.0.0.1",8888)

# 发起注册
def do_register(sockfd):
    while True:
        name = input("Name:")
        passwd = input("Password:")

        if ' ' in name or ' ' in passwd:
            print("用户名或者密码不许有空格")
            continue

        passwd_ = input("Again:")
        if passwd != passwd_:
            print("两次密码不一致")
            continue

        # 发送请求
        msg = "R %s %s"%(name,passwd)
        sockfd.send(msg.encode())
        # 等待反馈
        result = sockfd.recv(128).decode()
        if result == 'OK':
            print("注册成功")
        else:
            print("注册失败")
        return


# 启动函数
def main():
    # 创建套接字
    sockfd = socket()
    sockfd.connect(ADDR)

    # 一级界面
    while True:
        print("""
        ======== 登录界面 =========
         1.注册   2.登录   3.退出"
        ==========================
        """)

        cmd = input("请输入命令:")
        if cmd == "1":
            do_register(sockfd)
        elif cmd == "2":
            pass
        elif cmd == "3":
            pass
        else:
            print("请输入正确指令")

if __name__ == '__main__':
    main()