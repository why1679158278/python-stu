"""
dict 数据库处理模块

* 根据 服务端在处理过程中的需求 进行数据的处理
"""
import pymysql

class Database:
    def __init__(self):
        self.db = pymysql.connect(
            host = 'localhost',
            port = 3306,
            user = 'root',
            password = '123456',
            database = 'dict',
            charset = 'utf8')

    def create_cursor(self):
        self.cur = self.db.cursor()

    def close(self):
        # 关闭
        self.db.close()

    ########  根据服务端需求写函数 #######
    def register(self,name,passwd):
        sql = "select name from user where name=%s;"
        self.cur.execute(sql,[name])
        r = self.cur.fetchone() # (name,) ()
        if r:
            return False # 不允许注册

        # 插入该用户
        sql = "insert into user (name,passwd) values (%s,%s);"
        try:
            self.cur.execute(sql,[name,passwd])
            self.db.commit()
            return True # 注册了 用户
        except:
            self.db.rollback()
            return False
