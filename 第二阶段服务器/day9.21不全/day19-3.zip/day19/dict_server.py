"""
dict 服务端

* 接收请求
* 处理逻辑
* 给客户端反馈内容
"""

from socket import *
from multiprocessing import Process
from signal import *
import sys

HOST = "0.0.0.0"
PORT = 8888
ADDR = (HOST,PORT)

# 处理客户端请求
def handle(connfd):
    # 循环接收请求,分情况讨论
    while True:
        data = connfd.recv(1024).decode()
        print(data)
        if data == "R":
            pass


# 启动函数,搭建网络
def main():
    # 创建tcp 套接字
    sockfd = socket()
    sockfd.bind(ADDR)
    sockfd.listen(5)

    # 处理僵尸
    signal(SIGCHLD,SIG_IGN)

    print("Listen the port %d"%PORT)
    while True:
        try:
            connfd,addr = sockfd.accept()
            print("Connect from ",addr)
        except KeyboardInterrupt:
            sockfd.close()
            sys.exit("服务端退出")

        # 为客户端创建新的进程
        p = Process(target=handle,args=(connfd,))
        p.daemon = True
        p.start()

if __name__ == '__main__':
    main()