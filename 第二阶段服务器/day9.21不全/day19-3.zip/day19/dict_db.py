"""
dict 数据库处理模块

* 根据 服务端在处理过程中的需求 进行数据的处理
"""
import pymysql

class Database:
    def __init__(self):
        self.db = pymysql.connect(
            host = 'localhost',
            port = 3306,
            user = 'root',
            password = '123456',
            database = 'dict',
            charset = 'utf8')

    def create_cursor(self):
        self.cur = self.db.cursor()

    def close(self):
        # 关闭
        self.db.close()