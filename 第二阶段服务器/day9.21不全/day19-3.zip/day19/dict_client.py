"""
dict 客户端

* 发起请求
* 获取数据进行展示
"""

from socket import *

# 服务端地址
ADDR = ("127.0.0.1",8888)

# 启动函数
def main():
    # 创建套接字
    sockfd = socket()
    sockfd.connect(ADDR)

    # 一级界面
    while True:
        print("""
        ======== 登录界面 =========
         1.注册   2.登录   3.退出"
        ==========================
        """)

        cmd = input("请输入命令:")
        sockfd.send(cmd.encode())
        if cmd == "1":
            pass
        elif cmd == "2":
            pass
        elif cmd == "3":
            pass
        else:
            print("请输入正确指令")

if __name__ == '__main__':
    main()