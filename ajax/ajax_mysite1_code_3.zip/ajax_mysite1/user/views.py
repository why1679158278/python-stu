from django.http import HttpResponse
from django.shortcuts import render
from .models import User
import json
from django.core import serializers

# Create your views here.
def all_users(request):
    # # 方式1: python方式
    # # 1.从数据库获取数据,类型是QuerySet
    # users = User.objects.all()
    # # 2.遍历QuerySet,构造用户对象列表
    # res = []
    # for u in users:
    #     user = {}
    #     user['username'] = u.username
    #     user['age'] = u.age
    #     res.append(user)
    # # 3. 将对象序列化成json串
    # json_str = json.dumps(res)
    # print(json_str)
    # # 4. 响应回客户端浏览器,通过响应头告诉客户端是json格式的数据
    # return HttpResponse(json_str,
    #                     content_type='application/json')
    # 方式2:Django方式,(不推荐)
    users = User.objects.all()
    json_str = serializers.serialize('json',users)
    return HttpResponse(json_str)
