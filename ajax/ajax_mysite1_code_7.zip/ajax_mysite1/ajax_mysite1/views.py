from django.http import HttpResponse
from django.shortcuts import render


def test_xhr(request):
    return render(request, 'test_xhr.html')


def test_xhr_get(request):
    return render(request, 'test_xhr_get.html')


def test_xhr_get_server(request):
    return HttpResponse('this is ajax data')


def test_jq_get(request):
    return render(request, 'test_jq_get.html')


def test_jq_get_server(request):
    return HttpResponse('this is jq data')


def test_json(request):
    return render(request, 'test_json.html')


def register_view(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    elif request.method == 'POST':
        uname = request.POST.get('uname')
        return HttpResponse('%s注册成功!' % uname)


def test_cross(request):
    return render(request,'cross.html')

def cross_server(request):
    func = request.GET.get('callback')
    result = (func+"('我跨域成功了')")
    return HttpResponse(result)
