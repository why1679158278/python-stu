from django.urls import path
from . import views

urlpatterns = [
    path('all', views.all_users),
    path('index', views.user_index),
]
