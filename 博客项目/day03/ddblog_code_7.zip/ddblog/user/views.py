from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View
import json
from .models import UserProfile
import hashlib
# 在使用setting.py时,导入Django的模块
from django.conf import settings

import jwt
import time
from tools.logging_dec import logging_check
from django.utils.decorators import method_decorator

class UsersView(View):
    def get(self, request, username=None):
        if username:
            # 返回指定用户的信息
            try:
                user = UserProfile.objects.get(username=username)
            except Exception as e:
                print('get user error %s' % e)
                result = {'code': 10104, 'error': '用户名错误'}
                return JsonResponse(result)

            if request.GET.keys():
                # key是否在属性中
                data = {}
                for k in request.GET.keys():
                    if k == 'password':
                        continue
                    if hasattr(user, k):
                        data[k] = getattr(user, k)
                result = {'code': 200, 'username': username, 'data': data}
                return JsonResponse(result)

            else:
                result = {'code': 200, 'username': username,
                          'data': {'info': user.info, 'sign': user.sign,
                                   'nickname': user.nickname,
                                   'avatar': str(user.avatar)}}
                return JsonResponse(result)

        else:
            # 返回所有用户信息
            return HttpResponse('-返回所有用户信息-')

    def post(self, request):
        # 1.获取ajax请求提交的数据
        json_str = request.body
        # 2.将json串反序列化为对象
        json_obj = json.loads(json_str)
        print(json_obj)
        # 3. 获取数据
        username = json_obj['username']
        password_1 = json_obj['password_1']
        password_2 = json_obj['password_2']
        email = json_obj['email']
        phone = json_obj['phone']
        # 4. 数据检查
        # 4.1 用户名是否可用
        old_user = UserProfile.objects.filter(username=username)
        if old_user:
            result = {'code': 10100, 'error': '用户名已被占用!'}
            return JsonResponse(result)
        # 4.2 两次密码是否一致
        if password_1 != password_2:
            result = {'code': 10101, 'error': '两次密码不一致!'}
            return JsonResponse(result)
        # 4.3 密码hash处理
        md5 = hashlib.md5()
        md5.update(password_1.encode())
        password_m = md5.hexdigest()

        # 5.添加用户信息到数据库(需要做异常处理)
        try:
            user = UserProfile.objects.create(username=username,
                                              password=password_m,
                                              email=email,
                                              phone=phone,
                                              nickname=username)
        except Exception as e:
            print('create error is %s' % e)
            result = {'code': 10102, 'error': '用户名已被占用!'}
            return JsonResponse(result)

        # 生成token并返回
        token = make_token(username)
        print(token.decode())
        return JsonResponse({'code': 200, 'username': username,
                             'data': {'token': token.decode()}})

    @method_decorator(logging_check)
    def put(self, request, username):
        # 拿数据
        json_str = request.body
        json_obj = json.loads(json_str)
        # 修改对象
        request.myuser.sign = json_obj['sign']
        request.myuser.nickname = json_obj['nickname']
        request.myuser.info = json_obj['info']
        # 保存到数据库
        request.myuser.save()

        # 返回
        result = {'code': 200,
                  'username': request.myuser.username}
        return JsonResponse(result)


def make_token(username, expire=3600 * 24):
    key = settings.JWT_TOKEN_KEY
    now = time.time()
    payload = {'username': username, 'exp': now + expire}
    return jwt.encode(payload, key)


@logging_check
def user_avatar(request, username):
    if request.method != 'POST':
        result = {'code': 10105, 'error': '请使用POST请求'}
        return JsonResponse(result)
    user = request.myuser
    user.avatar = request.FILES['avatar']
    user.save()
    result = {'code': 200, 'username': user.username}
    return JsonResponse(result)
