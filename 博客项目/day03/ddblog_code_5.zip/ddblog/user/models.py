from django.db import models
import random


def default_sign():
    signs = ['健身达人', 'IT宅男', '自由职业人', '快递小哥']
    return random.choice(signs)


# Create your models here.
class UserProfile(models.Model):
    username = models.CharField(max_length=20, verbose_name="用户名",
                                primary_key=True)
    nickname = models.CharField(max_length=50, verbose_name="昵称",
                                default='')
    # 如何生成一个随机的个人签名默认值
    sign = models.CharField(max_length=50, verbose_name='个人签名',
                            default=default_sign)
    email = models.EmailField()
    password = models.CharField(max_length=32)
    info = models.CharField(max_length=150, verbose_name='个人简介',default='')
    avatar = models.ImageField(upload_to='avatar', null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)
    phone = models.CharField(max_length=11, default='')

    class Meta:
        db_table = 'user_user_profile'
