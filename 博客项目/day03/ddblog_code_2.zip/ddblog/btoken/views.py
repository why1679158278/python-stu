from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views import View


# Create your views here.
class TokensView(View):
    def get(self, request):
        return HttpResponse('-btoken get-')

    def post(self, request):
        
        result = {'code': 200}
        return JsonResponse(result)
