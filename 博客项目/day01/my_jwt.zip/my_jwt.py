import json
import base64
import time
import hmac
import copy


class Jwt():
    def __init__(self):
        pass

    # 1.生成token
    @staticmethod
    def encode(payload, key, exp=300):
        # 1.1 header
        # 定义json对象
        header = {'alg': 'HS256', 'typ': 'JWT'}
        # 序列化为json串
        header_js = json.dumps(header, separators=(',', ':'), sort_keys=True)
        print(header_js)
        # 将json串做base64编码
        header_bs = Jwt.b64encode(header_js.encode())
        print(header_bs)
        # 1.2 payload
        payload_data = copy.deepcopy(payload)
        payload_data['exp'] = time.time() + int(exp)
        # 序列化为json串
        payload_js = json.dumps(payload_data,
                                separators=(',', ':'),
                                sort_keys=True)
        # base64编码
        payload_bs = Jwt.b64encode(payload_js.encode())
        print(payload_bs)
        # 1.3 signer 签名
        hm = hmac.new(key.encode(),
                      header_bs + b'.' + payload_bs,
                      digestmod='SHA256')
        hm_bs = Jwt.b64encode(hm.digest())
        print(hm_bs)
        return header_bs + b'.' + payload_bs + b'.' + hm_bs

    # 2. 符合jwt的官方格式,base64编码后,去除=
    @staticmethod
    def b64encode(j_s):
        return base64.urlsafe_b64encode(j_s).replace(b'=', b'')

    # 4. 将去掉的=,补回来
    @staticmethod
    def b64decode(b_s):
        rem = len(b_s) % 4
        if rem > 0:  # 1,===;2,==;3,=;
            b_s += b'=' * (4 - rem)
        return base64.urlsafe_b64decode(b_s)

    # 3.验证token

    @staticmethod
    def decode(token, key):
        # 1 将token再拆分成三部分
        header_bs, payload_bs, sign = token.split(b'.')
        # 2 重新计算认证码
        hm = hmac.new(key.encode(),
                      header_bs + b'.' + payload_bs,
                      digestmod='SHA256')
        # 3 比较两个认证码是否相同
        if sign != Jwt.b64encode(hm.digest()):
            raise
        # 4 取payload(包含了私有声明和有效期)
        # 先对payload_bs补=
        payload_js = Jwt.b64decode(payload_bs)
        # 反序列化为对象
        payload = json.loads(payload_js)
        # 从payload对象中取出有效期
        exp = payload['exp']
        now = time.time()
        # 5 将有效期与当前时间比较
        if now > exp:
           raise
        return payload


if __name__ == '__main__':
    # 1 生成token
    token = Jwt.encode({'username': 'tedu'}, '123456',3)
    print(token)
    # time.sleep(4)
    # 2 验证token
    payload = Jwt.decode(token,'123456')
    print(payload)

