from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View


class UsersView(View):
    def get(self, request):
        return HttpResponse('-user get-')

    def post(self, request):
        return JsonResponse({'code': 200})
