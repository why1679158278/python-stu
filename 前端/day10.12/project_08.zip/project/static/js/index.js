// static/js/index.js
// console.log('外部js文件加载成功');
// console.log(faderData);

$(function () {
    // 声明本地图片路径
    // var BASE_URL = 'http://127.0.0.1:8000/'
    var BASE_URL = '../static/images/';
    var html = '';//保存拼接的文本内容
    // html += '<li class="silde">'
    // html += '<a href="#">'
    /*
        遍历faderDate,获取数组中的每一个元素(对象)
        将对象的属性依次拼接到html中
        <li class="slide">
            <a href="#">
                <img src="../static/images/banner01.jpg" alt="">
                <span class="imginfo">
                        爬虫微课5小时 Python学习路线!
                </span>
            </a>
        </li>
    */
    $.each(faderData,function(i,o){
        html += '<li class="slide">'
        html += '<a href="#">'
        html += `<img src="${BASE_URL+o.img_url}">`
        html += '<span class="imginfo">'
        html += o.img_info
        html += '</span></a></li>'
    })

    // console.log(html)
    // 添加到页面 找到兄弟元素 追加到兄弟元素上方
    $('.fader_controls').before(html);

    $('.fader').easyFader();

})