// static/js/index.js
console.log('外部js文件加载成功');
console.log(faderData);