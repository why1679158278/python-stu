"""
    复习
    1. 下载代码
        浏览器输入：code.tarena.com.cn
        账号：tarenacode
        密码：code_2013
        地址： AIDCode/aid2007/01_month01/
                to_student_for_month01.zip
    2. 创建Pycharm项目
        File - New Project - Location - Project Interpreter
"""