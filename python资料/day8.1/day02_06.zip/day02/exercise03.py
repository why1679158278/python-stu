"""
画出下列代码内存图,说出终端显示结果
name_of_hubei_province = "湖北"
name_of_hunan_province = "湖南"
name_of_hunan_province = "湖南省"
name_of_hunan_province = name_of_hubei_province
print(name_of_hunan_province)  # ?
"""
name_of_hubei_province = "湖北"
name_of_hunan_province = "湖南"
name_of_hunan_province = "湖南省"
name_of_hunan_province = name_of_hubei_province
print(name_of_hunan_province)  # 湖北
