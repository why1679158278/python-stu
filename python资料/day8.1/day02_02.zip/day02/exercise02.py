"""
    判断英文句子成分：I kiss you
"""
# 获取数据
subject = input("请输入I kiss you的主语：")
predicate = input("请输入I kiss you的谓语：")
object = input("请输入I kiss you的宾语：")

# 显示结果
print("你输入的是：")
# 主语是：xx,谓语是:xx,宾语是xx.
print("主语是：" + subject + ",谓语是:" + predicate + ",宾语是" + object + ".")
