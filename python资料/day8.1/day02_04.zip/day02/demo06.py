"""
    数据类型
"""
# 1. 整形int：整数
number01 = 30 + 1 # 数学运算 31

# 2. 浮点型float：小数
number02 = 1.2 + 0.5

# 3. 字符串str：文字
str_number = "30" + "1" # 文字拼接301
print("str_number") # 打印 - 文字 str_number
print(str_number) # 打印 - 变量   301

