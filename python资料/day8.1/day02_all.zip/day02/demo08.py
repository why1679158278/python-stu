"""
    运算符 - 算数运算符 + - *
                    /    小数商
                    //   整数商
                    %    余数
                    **   幂运算
                        5 ** 3 -->  5 * 5 * 5
    练习:exercise06~07

"""
data01 = 5
data02 = 2
data03 = data01 ** data02
print(data03)