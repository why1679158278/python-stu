# import package01.package02.m02

# 使用绝对路径(从根目录开始)
from package01.package02 import m02

# *使用相对路径
# from . import m02