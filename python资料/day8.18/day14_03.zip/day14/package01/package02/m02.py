def func01():
    print("m02 - func01")