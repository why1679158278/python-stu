def func01():
    print("module01 - func01执行喽")


def func02():
    print("module01 - func02执行喽")