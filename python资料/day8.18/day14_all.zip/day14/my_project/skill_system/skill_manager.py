class SkillManager:
    def func01(self):
        print("SkillManager - func01")


from skill_system.skill_deployer import SkillDeployer

deployer = SkillDeployer()
deployer.func02()
