"""
    while
        循环计数
"""
count = 0  # 开始
while count < 5:  # 结束
    print(count)  # 0 1 2 3 4
    count += 1  # 间隔
