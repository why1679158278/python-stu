"""
Day01串讲
"""
# name = input("请输入名字")
# print(name)  # 打印到控制台
#
# # 变量 关联一个对象的标识符。
# num = 5
# money = 35.26  # 科学计数法 xx * 10 ^n
# num = 0.000000000000000000000005
# print(num)
# name = "东东"

# 练习2 某商店T恤的价格为285元/件，裤子的价格为720元/条，
# # 小王在该店买了2将T恤和3条裤子，请计算小王应付多少钱，打3.9折以后呢
# 获取数据
# ts = 285
# trousers = 720
# # 逻辑分析
# result = ts * 2 + trousers * 3  # 应付 优先级
# resultA = result * 0.39  # 打折后
# # 输出结果
# print("小王应付 %s，打折后应付%s" % (result, resultA))

# 练习3：在终端中分别录入3个数据(分钟数、小时数、天数)
#       输出总秒数
minute = int(input("请输入分钟数："))
hour = int(input("请输入小时数："))
day = int(input("请输入天数："))

seconds = minute * 60 + hour * 60 * 60 + day * 24 * 60 * 60
print(seconds)
print(type(seconds))
# 练习4：在终端输入总秒数
#       输出(天数、小时数、分钟数、秒数)
# seconds = int(input("请在终端输入总秒数："))
days = seconds // 86400  # 一天86400 秒
hour = seconds % 86400 // 3600  # （总秒数-天数）//3600
minute = seconds % 86400 % 3600 // 60  # 求余刨除天数 %3600刨去小时数   将剩余的秒数除60得到分钟数
sec = seconds % 86400 % 3600 % 60
print(str(days) + "天" + str(hour) + "小时" + str(minute) + "分" + str(sec) + "秒")

# 练习5：编程实现计算几天是几周零几天（86是12周 零2天）
days = float(input("请用户输入天数"))
week = days // 7
day = days % 7
print("%s天是%s周零%d天" % (days, week, day))
# 6.请用户输入3课科成绩   如果有一个是100分就打印你好棒优秀
# 语文大于70 数学大于80英语大于90；
# 语文大于90 并且其中两门中有一门大于70
chinese = float(input("请用户输入成绩语文:"))
math = float(input("请用户输入成绩数学:"))
english = float(input("请用户输入成绩英语:"))
isA = chinese == 100 or math == 100 or english == 100
isBB = chinese > 70 and math > 80 and english > 90
isC = chinese > 90 and (math > 70 or english > 70)

isGood = isA or isBB or isC
print("%s你好棒很优秀" % isGood)