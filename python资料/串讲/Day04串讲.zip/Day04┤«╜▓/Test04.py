#容器
#字符串
# 字-----数
# num = ord("A")
# print(num)
# # 数====字
# str01 = chr(255)# 禁止瞎填
# print(str01)
#
# #转义字符：改变原有的含义的特殊字符
# str02 = "声音\t小了点呀"
# print(str02)
# url = r"D:\Python\第一阶段\PPT\01CORE.txt"
# print(url)
#格式化字符串 %d %s %f

# 列表 VS 字符串
#练习1：接收用户输入的字符串，将其中的字符以与输入相反的顺序输出。"abc"→"cba“.
# msg  = input("请输入一个字符串")
# list01 = []
# #将字符串中所有的字符以元素的形式存到了列表中
# for i in range(len(msg)):
#     list01.append(msg[i])
# #逻辑处理
# for x in range(len(list01)//2):
#     list01[x],list01[len(list01)-1-x] = list01[len(list01)-1-x],list01[x]
# result = "-".join(list01)
# #输出结果
# print(result)

# massag = input("请输入字符串")
# list02 =[massag[i] for i in range(len(massag))]
# #逻辑处理
# result ="-".join(list02[::-1])
# print(result)
#练习2：接收用户输入的一句英文，将其中的单词以反序输出。

# msg = input("请输入一句英文")# "I love you"
# list03 =msg.split(" ")
# result ="-".join(list03[::-1])
# print(result)

#创建字典
# dic = {}
# dic01 = dict()
#
# dic = {101:"x",102:"i",103:"d",104:"o"}
# #添加在我们的字典中[键] = 值
# dic[104]= "n"
#
# dic[104]= "f"
# #查找： 通过键去找值
# print(dic[104])
# if 105 in dic:
#     print(dic[105])
# #循环
# for k,v in dic.items():
#     print(k)
#     print(v)



#输入小写转大写1
#获取数据 想办法把字符串填到集合当中
mass = "1壹 2贰 3叁 4肆 5伍 6陆 7柒 8捌 9玖 0零"
list04 = mass.split(" ")
dic01 = {}# 创建字典
for i in range(len(list04)):#字典名字[键] = 值
    dic01[list04[i][0]] = list04[i][1]
input_str = input("输入小写，我们给您转成大写")
print(dic01[input_str])
""" 
2计算字符串中每个字符出现次数。
    输入：abcbdeacb
    输出：
        字符a,2次
        字符b,3次
        字符c,2次
        字符d,1次
        字符e,1次
"""
str_input = "abcbdeacb"
#键值对的题      思考   键     值
#字符------键    次数------ 值
dic02 = {}
#将键和值添加到字典当中
for i in str_input:
    #字典中不包含这个数据
    if i not in dic02:
        dic02[i] = 1
    #字典中包含该数据出现的次数增加1
    else:
        dic02[i] +=1# 出现的次数增加1
for k,v in dic02.items():
    print("字符%s，%d次"%(k,v))
"""
# 学生信息管理系统   课后练习
要求：请用户选择序号1-4，分别代表不同的选项
用户可以无线输入学生信息（姓名 年龄 QQ 地址），
如果选择1：需要输入4个信息分别是 姓名 年龄 QQ 地址
        2：用户只需要输入名字，你就要显示学生的四个信息
        3：你需要将前面用户输入的学员信息都显示出来
        4：退出输入系统

这道题是综合应用，用到循环 选择语句 列表 字典（仅供参考）

"""
print("="*50)
print("学生管理系统0.1版")
print("1.添加一个新学生信息")#学生信息包含姓名 年龄 QQ 地址
print("2.查询某个学生信息")
print("3.显示所有学生信息")
print("4.退出系统")




