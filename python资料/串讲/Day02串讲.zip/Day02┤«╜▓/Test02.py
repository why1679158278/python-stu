# if语句
# 石头剪子布
# 请用户输入 012
# 电脑随机一个
# 判断谁赢了
import random

# # 获取数据
# # player = input("请输入0--石头，1剪子，2布石头剪子布：")
# # computer = random.randint(0, 2)
# # result = ""
# # # 逻辑处理
# # if (player == 0 and computer == 1) or (player == 1 and computer == 2) or (player == 2 and computer == 0):
# #     result = ("玩家赢了")
# # elif player == computer:
# #     result = ("平局，决战吧")
# # else:
# #     result = ("输了，回家拿钱去吧")
# # print(result)

# 2.小明有10元钱 去买咖啡 小杯 5元 中杯8元 大杯11元
# 如果钱够，打印余额，不够告知不够

# 获取数据
# money = 10
# size = input("请输入要买的规格0 小杯 1中杯 2 大杯：")
# # 逻辑处理
# if size == "0":
#     money -= 5
# elif size == "1":
#     money -= 10
# elif size == "2":
#     if money >= 11:
#         money -= 11
#     else:
#         print("钱不够，买不了")
#
# # 输出结果
# print(money)

"""
1. 可以组合成多路分支语句，用来实现根据多个条件多选一执行，比如：分段打折问题：
   如果商品总价大于等于800，则打7折
   如果商品总价小于800大于等于500，则打8折
   如果商品总价小于500大于等于200，则打9折
   如果商品总价小于200，则打95折
"""
# 求1-100之间的偶数
# 分析 循环条件：1-100
# 循环体：求偶数
# i = 1
# while i <= 100:
#     if i % 2 == 0:  # 求偶数
#         print(i)
#     i += 1
# 求1-100之间的20个偶数
# 分析
# 循环条件：1-100
# 循环体：
# i = 1
# num = 0
# while i <= 100:
#     if i % 2 == 0:  # 求偶数
#         print(i)
#         num+=1
#     if num==20:
#         break;# 退出循环
#     i += 1
# 3.今年达内学员达到了9万  每年增长20% 请问多少年以后可以达到30万
# 循环条件：<30万
# 循环体： 增长20%  原来的

# student = 90000
# year = 2020
# while student < 300000:
#     student *= 1.2
#     year += 1
# else:
#     print("到%d年达内人数增长到30万" % year)

# massage = "我是隔壁老王"
# for i in massage:
#     print(i)
# # 用for循环求奇数
# for item in range(1, 100):
#     if item % 2 != 0:
#         print(item)
# for item in range(1, 100, 2):
#     print(item)

# 打印1 - 100数字  但是如果能被7整除或者位数是7就忽略不打印
# for i in range(1, 101):
#     if i % 7 == 0 or i % 10 == 7 or i // 10 == 7:
#         continue
#     print(i)

# 用列表存储3个人的名片信息（每个人的信息包含姓名 年龄性别）
#让玩家输入查询的名字
#查找列表中的内容  如果找到了就找到了，没找到返回没找到
# 分析     获取数据    逻辑处理   输出结果








"""
    创建列表，存储水星，金星，地球，木星，土星，天王星。
    向列表中追加海王星。
    在地球后插入火星。
    打印距离太阳最远的行星(最后一个行星)
    打印地球之前的所有行星(前两个行星)。
    删除金星。
    删除地球后面的所有行星。
    倒序打印所有行星。
"""










"""
    列表内存分配
"""
list01 = [10, 20]
list02 = list01
list01[0] = 100
print(list02[0])  # ?100

list01 = [10, 20]
list02 = list01
list01 = 100
print(list02[0])  # ?10

# 练习：
list01 = [10, 20]
list02 = list01[:]
list01[0] = 100
print(list02[0])  # ?

import copy

list01 = [10, [20, 30]]
list02 = list01[:]  # 浅拷贝
list03 = list01  # 赋值
list04 = copy.deepcopy(list01)  # 深拷贝

# 深拷贝
# 优点:互不影响
# 缺点：往往占用内存过多












