# 字典常用操作
dict01 = {1001: "悟空"}

# 添加(没有k)
dict01[1002] = "唐僧"

# 修改(有k)
dict01[1001] = "孙悟空"

# 遍历
for key in dict01:
    print(key)
for value in dict01.values():
    print(value)
for key, value in dict01.items():
    print(key)
    print(value)
# 删除
del dict01[1002]

# list(dict01.items())

# 创建
list01 = ["悟空"]
# 添加
list01.append("唐僧")
list01.insert(0, "八戒")
# 定位
list01[1] = "孙悟空"
list01[:2] = ["三藏", "大圣"]
# 遍历
for item in list01:
    print(item)
for i in range(len(list01)):
    print(list01[i])
# 删除
del list01[0]
list01.remove("大圣")
