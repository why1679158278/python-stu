"""

"""

# 做法
# 参数：使用函数时 给　创建函数传递的信息
# 形式参数
def repeated_attack(count):
    """
        重复攻击
    :param count:int类型,攻击次数　
    """
    for __ in range(count):
        print("正蹬")
        print("直拳")
        print("摆拳")
        print("勾拳")
# 数据
# 实际参数
repeated_attack(2)
repeated_attack(3)