class SkillDeployer:
    def func02(self):
        print("SkillDeployer - func02")


from common.list_helper import ListHelper

ListHelper.func03()