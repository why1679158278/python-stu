"""
    main.py
"""
from skill_system.skill_manager import SkillManager

manager = SkillManager()
manager.func01()


# 非主流做法

# import skill_system

# skill_system.skill_manager.SkillManager().func01()

# skill_system.SkillManager().func01()
