"""
    列表内存图
        遍历
"""
list01 = [10, 20, 30]

for item in list01:
    print(item)

for i in range(len(list01)-1,-1,-1):
    print(list01[i])


