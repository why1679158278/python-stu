"""

"""
region = "湖北"
confirmed = 67802
cure = 63326
rate_cure = 0.99
print("%s确诊%d人,治愈%d人,治愈率%.2f"%(region,confirmed,cure,rate_cure))


total_second = 70
minute = total_second // 60
second = total_second % 60
print("%d秒是%.2d分零%d秒"%(total_second,minute,second))





