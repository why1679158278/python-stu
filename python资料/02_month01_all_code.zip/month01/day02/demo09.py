"""
    运算符 - 增强运算符
        在算数运算符基础上,增加了为自身赋值的功能
        +=  -=  *=  /=  //=   %=  **=
    练习:exercise08
"""
data01 = 10
# data01 + 5
# print(data01) # 10

data01 += 5   # data01 = data01 + 5
print(data01)  # 15
