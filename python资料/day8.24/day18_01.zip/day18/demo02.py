"""
    闭包
        三大要素
            有外有内
            内访问外
            外返回内
"""


def func01():
    a = 10

    def func02():
        print(a)

    # 返回内部函数,没有调用内部函数.
    return func02

# 调用外部函数,结果是内部函数
result = func01()
# 调用内部函数
result()
result()
