"""
    在终端中录入一个内容,循环打印每个文字的编码值。
"""
for chr in input("请输入文字："):
    print(ord(chr))
