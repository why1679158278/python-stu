"""
    编码:字 -> 数
    解码:数 -> 字
    https://unicode-table.com/cn/
"""
number = ord("釹")# 字 -> 数
print(number)

char = chr(20002)# 数 -> 字
print(char)
