"""
    复习
    1. 程序结构
        根目录(主模块所在文件夹)
            包
                模块
                    类
                        函数
                            语句
            main.py

    2. 导入：
        import 路径.模块
        from 路径 import 模块

        # 以下操作,必须在包的__init__.py文件中配置
        import 包
        from 路径 import 包

    3. 导入是否成功的唯一标准：
        导入路径 + sys.path = 真实路径
"""