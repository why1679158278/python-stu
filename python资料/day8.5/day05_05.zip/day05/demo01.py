"""
    索引
        容器名[整数]
        定位某个位置的数据
"""
message = "我是齐天大圣孙悟空"
print(message[0])# 我
# print(message[99])# IndexError
print(message[-2])# 悟
