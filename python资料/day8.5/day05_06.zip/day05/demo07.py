"""
    列表内存图
        添加
        删除
"""
list01 = [10, 20, 30]
# 腾
list01.insert(1, 40)
# 挤
del list01[-2]

