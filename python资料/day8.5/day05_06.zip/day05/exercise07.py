# 练习：
list01 = ["北京", "上海", "深圳"]
for item in list01:
    print(item)

for i in range(len(list01)-1,-1,-1):
    print(list01[i])
