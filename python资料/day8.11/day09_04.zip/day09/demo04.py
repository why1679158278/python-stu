"""
    函数参数
        形式参数
"""


# 星号元组形参：位置实参数量无限   合
def func01(*args):
    print(args)


func01()  # 空元组
func01(1, 2)  # (1,2)
# func01(p1=1, p2=2) # 报错
