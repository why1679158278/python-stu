

from docx import Document

document = Document("demo02.docx")
paragraphs = document.paragraphs
print(paragraphs)

# 登高                           -- paragraph run
# 作者：杜甫                      -- paragraph run
# 风急天高猿啸哀，渚清沙白鸟飞回。    -- paragraph run
# 无边落木萧萧下 不尽长江滚滚来。     -- paragraph run  run  run
# 万里悲秋常作客，百年多病独登台。    -- paragraph run  run  run
# 艰难苦恨繁霜鬓a潦倒新停浊酒杯。     -- paragraph run  run  run

