import time
from shutil import copyfile
from docx import Document
import os
import re

destination_folder = "奖状"

# 如果目标文件夹不存在
if not os.path.exists(destination_folder):
    os.mkdir(destination_folder)

# 模板文件的占位符列表
list_placeholders = ["school", "class", "name", "yyyy", "mm", "dd"]
times = ["%.2d" % t for t in time.localtime()[:3]]  # ["2020", "07", "10"]

# os.listdir 获取目录中所有文件名称
for file_name in os.listdir("全国面向对象答辩第一名收集"):
    infos = re.split("[_.]", file_name)[:3]  # 北京_2007_郭德纲.pptx -->  ["北京","2006","郭德纲"]
    destination_file_name = os.path.join(destination_folder, infos[2] + ".docx")  # 奖状/郭德纲.docx
    copyfile("奖状模板.docx", destination_file_name)  # 奖状模板.docx　-> 奖状/郭德纲.docx

    # ["school", "class","name", "yyyy", "mm", "dd"]
    # ["北京","2006","郭德纲"] + ["2020", "04", "10"]
    # key:占位符   vlaue:填充内容
    data_of_person = dict(zip(list_placeholders, infos + times))

    doc = Document(destination_file_name)
    for graph in doc.paragraphs:
        for run in graph.runs:
            if run.text in data_of_person:#如果当前字块是模板文件的占位符
                run.text = data_of_person[run.text]
    doc.save(destination_file_name)
