"""
    python-docx 做职场高手,让word文档自动化,击败无聊的办公室重复性操作
    安装：
        pip3 install python-docx
    word文档结构：
        Document 文档
            Paragraph 段落
                Run字块(字体、样式...)
"""

from docx import Document

document = Document("demo01.docx")
paragraphs = document.paragraphs
print(paragraphs)

# 登高                            -- paragraph run
# 作者：杜甫                       -- paragraph run
# 风急天高猿啸哀，渚清沙白鸟飞回。     -- paragraph run
# 无边落木萧萧下，不尽长江滚滚来。     -- paragraph run
# 万里悲秋常作客，百年多病独登台。     -- paragraph run
# 艰难苦恨繁霜鬓，潦倒新停浊酒杯。     -- paragraph run
