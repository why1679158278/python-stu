"""
    业务逻辑层
"""
from dal import HouseDao


class HouseManagerController:
    def __init__(self):
        self.__list_houses = HouseDao.load()

    @property  # list_houses = property(list_houses)
    def list_houses(self):
        return self.__list_houses
