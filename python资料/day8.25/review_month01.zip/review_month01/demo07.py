"""
    property 属性 -- 拦截
    装饰器 -- 拦截
"""


class Wife:
    def __init__(self, age=0):
        self.age = age

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        self.__age = value

    # def get_age(self):
    #     return self.__age
    #
    # def set_age(self, value):
    #      self.__age = value

    # age = property(get_age)
    # age = age.setter(set_age)

w01 = Wife(250)
print(w01.age)


def new_func(func):
    def wrapper():
        print("新功能")
        func()
    return wrapper

@new_func
def func01():
    print("func01功能")

# func01 = new_func(func01)

func01()