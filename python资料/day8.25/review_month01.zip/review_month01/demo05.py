"""
    Python 高级
        1. 程序结构
            根目录:主模块(第一次运行的文件)所在文件夹
            包与模块导入:
                路径:从根目录开始
                是否成功唯一标准:
                    导入路径 + 系统路径 = 真实路径
                语法:
                    import 模块名
                    模块名.成员

                    from 模块名 import 成员
        2. 异常处理
              核心价值:保障程序能够按照既定流程执行,不混乱.
              处理原则:就近处理
              异常现象:不再继续向下执行,不断向上返回.
              A --> B  -->  C -->  D  -->  E
        3. 生成器
                语法:
                      生成器函数
                            def 函数名():
                                yield 数据

                            for item in 函数名():
                                ...
                      生成器表达式
                            (for 变量 in 可迭代对象 if 条件)
                核心:
                      惰性操作/延迟操作
                      不是立即返回数据,而是返回推算数据的对象


"""
try:
    print("可能出错的代码")
    raise Exception  # raise 后面跟异常对象,但是可以不写小括号
# except Exception:
except:  # except 后面不跟异常类型,默认为Exception
    print("出错喽")


# 函数只有一个结果,使用return返回
def func01():
    return "结果1"

re01 = func01()
print(re01)

# 函数只有多个结果,使用yield返回
def func02():
    # yield 将函数切割为多个__next__函数
    yield "结果1"
    yield "结果2"
    yield "结果3"

# 以下代码展示生成器原理(调用一次 计算一次 返回一次)
# generator = func02()
# re02 = generator.__next__()
# print(re02)
# re03 = generator.__next__()
# print(re02)
# re03 = generator.__next__()
# print(re02)

# 只能通过for循环从头到尾获取所有数据
for item in func02():
    print(item)

# 若是转换为立即操作,就可以通过索引定位元素
# 惰性操作(不存数据数据,所以省内存) --> 立即操作(可以通过索引访问元素,所以灵活)
re04 = list(func02())
print(re04[1])
print(re04)