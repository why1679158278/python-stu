"""
    面向对象(1)
        类和对象语法
"""


class MyClass:
    # 一.数据
    # 2.类变量:大家的数据
    data02 = 20

    # 1.实例变量:自己的数据
    def __init__(self, data01):
        self.data01 = data01

    # 二.行为
    # 1.实例方法:对象的行为(操作实例变量)
    def func01(self):
        print("实例变量:", self.data01)

    # 2.类方法:大家的行为(操作类变量)
    @classmethod
    def func02(cls):
        # MyClass.data02
        print("类变量:", cls.data02)

    # 3.静态方法:不需要操作实例成员与类成员(工具函数)
    @staticmethod
    def func03():
        print("静态方法")


# 创建对象
instance = MyClass(10)
# 访问实例成员
print(instance.data01)
instance.func01()# 自动传递对象进入方法  func01(instance)
# 访问类成员
print(MyClass.data02)
MyClass.func02()# 自动传递类进入方法  func02(MyClass)
# 访问静态方法
MyClass.func03() # 不会自动传递参数



