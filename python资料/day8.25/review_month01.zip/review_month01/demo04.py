"""
    实例成员与类成员适用性
"""

class XXModel:
    def __init__(self,id = 0):
        self.id = id # 由XXController内部确定

"""
class XXController:
    def __init__(self):
        self.__models = []
        self.__index = 0 # 实例变量:每个个体的数据   [杯子]

    def add_data(self,data):
        data.id = self.__index
        self.__index += 1
        self.__models.append(data)

if __name__ == '__main__':
    controller = XXController()
    model = XXModel()
    controller.add_data(model)# 0 -> 1
    print(model.id)

    controller = XXController()
    model = XXModel()
    controller.add_data(model)# 0 -> 1
    print(model.id)
"""


class XXController:
    __index = 0  # 类变量:大家的数据(每个个体都可共享)  [饮水机]

    def __init__(self):
        self.__models = []

    def add_data(self,data):
        data.id = XXController.__index
        XXController.__index += 1
        self.__models.append(data)

if __name__ == '__main__':
    controller = XXController()
    model = XXModel()
    controller.add_data(model)# 0 -> 1
    print(model.id)

    controller = XXController()
    model = XXModel()
    controller.add_data(model)# 1 -> 2
    print(model.id)