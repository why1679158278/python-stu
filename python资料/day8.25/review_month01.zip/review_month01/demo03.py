"""
    面向对象(2)
        三大特征
"""
# 1. 直接创建对象
"""
class ClassA:
    def func01(self):
        # 调用类方法或者静态方法,只有一种写法.(通过类名访问)
        ClassB.func03()
        b = ClassB()
        b.func02()

class ClassB:
    def func02(self):
        print("func02执行喽")

    @classmethod
    def func03(cls):
        print("func03执行喽")

a = ClassA()
a.func01()
"""

# 2. 在构造函数中创建对象
"""
class ClassA:
    def __init__(self):
        self.b = ClassB()

    def func01(self):
        self.b.func02()

class ClassB:
    def func02(self):
        print("func02执行喽")

a = ClassA()
a.func01()
"""

# 3. 不在类中创建对象,而是通过参数传入
class ClassA:
    def func01(self, b):
        b.func02()

class ClassB:
    def func02(self):
        print("func02执行喽")

a = ClassA()
b = ClassB()
a.func01(b)
