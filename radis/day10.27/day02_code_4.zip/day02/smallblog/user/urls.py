from django.urls import path

from . import views
urlpatterns=[
    # 显示个人信息
    # http://127.0.0.1:8000/user/detail/1
    path('detail/<int:uid>',views.show_user),
    # 修改个人信息
    # http://127.0.0.1:8000/user/update/1?age=300
    path('update/<int:uid>',views.update_user)
]