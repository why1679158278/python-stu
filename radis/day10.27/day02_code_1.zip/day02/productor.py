import redis

# 创建redis对象
r = redis.Redis(host='127.0.0.1', port=6379,
                db=0, password='123456')

if __name__ == '__main__':
    # 任务格式: 任务类别_发送者_接收者_内容
    task = '%s_%s_%s_%s' % ('sendMail', '123@tedu.com',
                            '456@tedu.com', 'helloworld')
    print(task)
    # 将任务放到队列(列表)中
    r.lpush('pyl1', task)
