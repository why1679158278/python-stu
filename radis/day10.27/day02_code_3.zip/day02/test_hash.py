import redis

r = redis.Redis(password='123456')

if __name__ == '__main__':
    r.flushdb()
    r.hset('pyh1', 'name', 'tedu')
    print(r.hget('pyh1', 'name'))
    r.hmset('pyh1', {'age': 18, 'city': '北京',
                     'type': 'ITTrainning'})
    # 不存在的field,返回None
    print(r.hmget('pyh1', ['age', 'type','user']))
    print(r.hgetall('pyh1'))
    # 拿到的结果,无论是键还是值,都是字节串
    # 特别是有中文字符时,需要将字节串转换为字符串
    print(r.hget('pyh1', 'city').decode())
