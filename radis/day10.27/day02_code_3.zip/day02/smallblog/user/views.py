from django.http import HttpResponse
from django.shortcuts import render

from .models import User
import redis

# redis对象
r = redis.Redis(password='123456')


# Create your views here.
def show_user(request, uid):
    cache_key = 'user:%s' % uid
    # 判断缓存中是否有数据
    if r.exists(cache_key):
        # 有缓存
        data = r.hmget(cache_key,['username','age'])
        print(data)

        username = data[0].decode()
        age =  data[1].decode()

        html='cache:username is %s,age is %s'%(username,age)
        return HttpResponse(html)
    else:
        # 无缓存
        # 1.从mysql中读取数据
        try:
            user = User.objects.get(id=uid)
        except:
            return HttpResponse('-uid is error-')
        # 2.写入redis中
        r.hmset(cache_key, {'username': user.username,
                            'age': user.age})
        # 设置有效期10秒
        r.expire(cache_key, 10)
        # 3. 返回数据
        html = 'mysql:username is %s,age is %s' % (user.username,
                                                   user.age)
        return HttpResponse(html)


def update_user(request, uid):
    return HttpResponse('修改用户%s信息' % uid)
