import redis

r = redis.Redis(password='123456')

if __name__ == '__main__':
    # 从队列中不断的取出任务
    while True:
        # 阻塞的方式取出任务
        task = r.brpop('pyl1', 5)
        # b'pyl1', b'sendMail_123@tedu.com_456@tedu.com_helloworld'
        #  任务: task[1],字节串
        # print(task)
        if task:
            data = task[1]
            # 转成字符串方便处理
            data_str = data.decode()
            # 分割以得到具体数据
            data_lst = data_str.split('_')
            print(data_lst)
            # 根据任务类别,执行相关任务(一般比较耗时)
            if data_lst[0] == 'sendMail':
                print('-执行发送邮件的函数-')

        else:
            print('-no task!-')
