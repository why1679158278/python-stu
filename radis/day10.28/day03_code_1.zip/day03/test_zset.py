import redis

r = redis.Redis(password='123456')

if __name__ == '__main__':
    r.zadd('pyz1', {'tedu': 100, 'tedu2': 200, 'tedu3': 300})
    r.zadd('pyz2', {'tedu2': 300})
    # 不带权重时,参与计算的键放到一个列表中
    r.zunionstore('pyz3', ['pyz1', 'pyz2'], aggregate='sum')
    print(r.zrange('pyz3', 0, -1, withscores=True))
    # 带权重时,参与计算的键放到一个字典中
    r.zunionstore('pyz4', {'pyz1': 0.2, 'pyz2': 0.8}, aggregate='sum')
    print(r.zrange('pyz4', 0, -1, withscores=True))
