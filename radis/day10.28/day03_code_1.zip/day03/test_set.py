import redis

r = redis.Redis(password='123456')

if __name__ == '__main__':

    r.sadd('武将', '周瑜', '张飞', '吕布', '赵云')
    r.sadd('文臣', '诸葛亮', '司马懿', '郭嘉', '周瑜')
    # 文武双全之人
    results = r.sinter('武将','文臣')
    # 纯武将
    results2 = r.sdiff('武将','文臣')
    # 纯文臣
    results3 = r.sdiff('文臣', '武将')
    # 文臣+武将
    results4 = r.sunion('文臣', '武将')
    for r in results4:
        print(r.decode())
