import redis
import time

pool = redis.ConnectionPool(password='123456')
r = redis.Redis(connection_pool=pool)

# 0.02
def withpipeline(r):
    # 创建流水线对象
    pipe = r.pipeline()
    for i in range(1000):
        key = 'test1' + str(i)
        value = i + 1
        pipe.set(key, value)
    pipe.execute()

# 0.18
def withoutpipeline(r):
    for i in range(1000):
        key = 'test2' + str(i)
        value = i + 1
        r.set(key, value)


if __name__ == '__main__':
    t1 = time.time()
    withoutpipeline(r)
    t2 = time.time()
    print('time is %s' % (t2 - t1))
