import redis
import time

pool = redis.ConnectionPool(password='123456')
r = redis.Redis(connection_pool=pool)


def double_account(user_id):
    key = 'account_%s' % (user_id)
    with r.pipeline(transaction=True) as pipe:
        while True:
            try:
                pipe.watch(key)
                value = int(r.get(key))
                value = value * 2
                print('-new value is %s-' % value)
                print('-sleep is start-')
                time.sleep(20)
                print('-sleep is stop-')
                pipe.multi()
                pipe.set(key,value)
                pipe.execute()
                break
            except redis.WatchError:
                print('-value is changed!-')
                continue
    return r.get(key)


if __name__=='__main__':
    print(double_account('tedu'))